package com.snhu.sslserver;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.crypto.SecretKey;
import java.security.NoSuchAlgorithmException;



@SpringBootApplication
public class SslServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(SslServerApplication.class, args);
	}

}




//FIXME: Add route to enable check sum return of static data example:  String data = "Hello World Check Sum!";

@RestController
@RequestMapping("/hash")
class HashController {

    @GetMapping
    public String getChecksum() {
        try {
            String data = "Hello World Check Sum!";
            SecretKey secretKey = CryptoUtils.generateAESKey();
            String encryptedData = CryptoUtils.encrypt(data, secretKey);
            String checksum = CryptoUtils.generateSHA256Hash(encryptedData);
            return "Checksum: " + checksum;
        } catch (Exception e) {
            e.printStackTrace();
            return "Error generating checksum";
        }
    }
}



